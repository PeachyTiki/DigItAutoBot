import time
import mss
import numpy as np
import cv2
import pyautogui
import keyboard


def get_regions():
    """Define screen regions for detecting game elements."""
    screen_width, screen_height = pyautogui.size()
    inventory_region = {
        "left": 0,
        "top": int(screen_height * 0.9),
        "width": screen_width,
        "height": int(screen_height * 0.1)
    }
    digging_region = {
        "left": 0,
        "top": int(screen_height * 0.8),
        "width": screen_width,
        "height": int(screen_height * 0.05)
    }
    progress_region = {
        "left": 0,
        "top": int(screen_height * 0.86),
        "width": screen_width,
        "height": int(screen_height * 0.03)
    }
    return inventory_region, digging_region, progress_region


def capture_region(region):
    """Capture a region using mss and return a BGR image."""
    with mss.mss() as sct:
        img = np.array(sct.grab(region))
    return cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)


def detect_mini_game_box(img):
    """Detect the mini-game box using edge detection and dark color filtering."""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150)
    projection = np.sum(edges, axis=0)
    border_cols = np.where(projection > 50)[0]
    if border_cols.size == 0:
        return None
    left = int(border_cols[0])
    right = int(border_cols[-1])
    return left, 0, right - left, img.shape[0]


def detect_colored_bar(img, mini_box):
    """Find the colored bar inside the mini-game box."""
    x, y, w, h = mini_box
    offset_x = int(0.03 * w)
    offset_y = int(0.2 * h)
    new_x = x + offset_x
    new_y = y + offset_y
    new_w = w - 2 * offset_x
    new_h = h - 2 * offset_y
    if new_w <= 0 or new_h <= 0:
        return None
    inner_img = img[new_y:new_y + new_h, new_x:new_x + new_w]
    hsv = cv2.cvtColor(inner_img, cv2.COLOR_BGR2HSV)

    rarity_hexes = ["#4b0001", "#545253", "#4b9752", "#5681a8", "#5a4b97", "#aa8a54", "#aa5454"]
    mask_total = np.zeros(hsv.shape[:2], dtype=np.uint8)

    for hex_code in rarity_hexes:
        lower, upper = detect_mini_game_box(hex_code)
        mask = cv2.inRange(hsv, lower, upper)
        mask_total = cv2.bitwise_or(mask_total, mask)

    contours, _ = cv2.findContours(mask_total, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None

    max_contour = max(contours, key=cv2.contourArea)
    cx, cw = cv2.boundingRect(max_contour)[0], cv2.boundingRect(max_contour)[2]
    return new_x + cx, new_x + cx + cw


def main():
    """Main loop for detecting and playing the mini-game."""
    pyautogui.press("1")
    inventory_region, digging_region, progress_region = get_regions()
    last_auto_click = time.time()

    while True:
        if keyboard.is_pressed("esc"):
            break

        if time.time() - last_auto_click > 3:
            pyautogui.click(pyautogui.size()[0] // 2, pyautogui.size()[1] // 2)
            last_auto_click = time.time()

        digging_img = capture_region(digging_region)
        mini_box = detect_mini_game_box(digging_img)

        if mini_box:
            colored_bounds = detect_colored_bar(digging_img, mini_box)
            if colored_bounds is None:
                continue

            target_center = (colored_bounds[0] + colored_bounds[1]) / 2
            print(f"Target Center: {target_center}")


if __name__ == "__main__":
    main()
